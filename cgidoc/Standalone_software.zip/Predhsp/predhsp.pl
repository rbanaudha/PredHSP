#!/usr/bin/perl

#This program run as a standalone at any Mac system
#Uses:perl predhsp.pl Input_fasta_file Threshold
#User can submit more than one protein sequences at a time
#Protein sequences should be in fasta format
#The final result saved in file Result

$input_file=$ARGV[0];
system "perl fasta.pl $input_file >input.fasta";#Convert two line fasta file
system "grep -c '>' input.fasta >total_seq";
system "grep '>' input.fasta |cut -d '|' -f3 |cut -d ' ' -f1 >protein_id"; #Grep protein id
system "perl dipep.pl input.fasta >dipep_comp";
system "sed -e 's/^/+1 /' dipep_comp >final";
system "svm_classify final hsp_dipep_1st_level_model svm_score_leve1_hsp >/dev/null";
system "svm_classify final hsp20_dipep_model svm_score_leve2_hsp20 >/dev/null";
system "svm_classify final hsp40_dipep_model svm_score_leve2_hsp40 >/dev/null";
system "svm_classify final hsp60_dipep_model svm_score_leve2_hsp60 >/dev/null";
system "svm_classify final hsp70_dipep_model svm_score_leve2_hsp70 >/dev/null";
system "svm_classify final hsp90_dipep_model svm_score_leve2_hsp90 >/dev/null";
system "svm_classify final hsp100_dipep_model svm_score_leve2_hsp100 >/dev/null";
system "paste protein_id final svm_score_leve1_hsp svm_score_leve2_hsp20 svm_score_leve2_hsp40 svm_score_leve2_hsp60 svm_score_leve2_hsp70 svm_score_leve2_hsp90 svm_score_leve2_hsp100 >final_svm";
system "tr '\t' '#' <final_svm >final_pred";

open(FINAL_PRED,"final_pred") or die "$!";
while($pred=<FINAL_PRED>)
{
    chomp($pred);
    @svm=split(/#/,$pred);
    #print "$svm[2]\n";
    if($svm[2] < $ARGV[1])
    {
	open(RESULT,">>Result") or die "$!";
	print RESULT "$svm[0]\tNon-HSP\n";
	close RESULT;
    }
    else
    {
	if(($svm[3] > $svm[4])&&($svm[3] > $svm[5])&&($svm[3] > $svm[6])&&($svm[3] > $svm[7])&&($svm[3] > $svm[8]))
	{
	    open(RESULT,">>Result") or die "$!";
	    print RESULT "$svm[0]\tHSP20 sub-family\n";
	    close RESULT;
	}
	if(($svm[4] > $svm[3])&&($svm[4] > $svm[5])&&($svm[4] > $svm[6])&&($svm[4] > $svm[7])&&($svm[4] > $svm[8]))
	{
	    open(RESULT,">>Result") or die "$!";
	    print RESULT "$svm[0]\tHSP40 sub-family\n";
	    close RESULT;
	}
	if(($svm[5] > $svm[3])&&($svm[5] > $svm[4])&&($svm[5] > $svm[6])&&($svm[5] > $svm[7])&&($svm[5] > $svm[8]))
	{
	    open(RESULT,">>Result") or die "$!";
	    print RESULT "$svm[0]\tHSP60 sub-family\n";
	    close RESULT;
	}
	if(($svm[6] > $svm[3])&&($svm[6] > $svm[4])&&($svm[6] > $svm[5])&&($svm[6] > $svm[7])&&($svm[6] > $svm[8]))
	{
	    open(RESULT,">>Result") or die "$!";
	    print RESULT "$svm[0]\tHSP70 sub-family\n";
	    close RESULT;
	}
	if(($svm[7] > $svm[3])&&($svm[7] > $svm[4])&&($svm[7] > $svm[5])&&($svm[7] > $svm[6])&&($svm[7] > $svm[8]))
	{
	    open(RESULT,">>Result") or die "$!";
	    print RESULT "$svm[0]\tHSP90 sub-family\n";
	    close RESULT;
	}
	if(($svm[8] > $svm[3])&&($svm[8] > $svm[4])&&($svm[8] > $svm[5])&&($svm[8] > $svm[6])&&($svm[8] > $svm[7]))
	{
	    open(RESULT,">>Result") or die "$!";
	    print RESULT "$svm[0]\tHSP100 sub-family\n";
	    close RESULT;
	}
    }
}
system "rm svm_score_leve2_hsp100 svm_score_leve2_hsp20 svm_score_leve2_hsp40 dipep_comp svm_score_leve2_hsp60 svm_score_leve2_hsp70 svm_score_leve2_hsp90 final input.fasta total_seq final_pred final_svm protein_id svm_score_leve1_hsp";
