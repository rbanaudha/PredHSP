#!/usr/bin/perl
use Getopt::Std;
getopts('i:ht:');

$input_file=$opt_i;
$svm_th=$opt_t;
#$input_file=$ARGV[0];
#$svm_th=$ARGV[1];

if(($opt_i eq '')||($opt_t eq '')||($opt_h == 1))
{

    print "usage: predhsp.pl -i <sequence input file> -t <svm threshold> -h <help>\n";
    exit();
}

#system "./seqret -sequence $input_file -outseq seq.seqret";

system "cat $input_file|cut -d ' ' -f1 |tr '\n' '#' |tr '>' '\n' |sed -e 's/#/:+1:/' -e 's/#//g' |tail -n +2 > seq.final";
#system "cat seq.seqret|cut -d ' ' -f1 |tr '\n' '#' |tr '>' '\n' |sed -e 's/#/:+1:/' -e 's/#//g' |tail -n +2 > seq.final";

open(OUTPUT,">result_predhsp") or die "$!";
print OUTPUT "Sr. No.\tName\tSVM score\tPrediction\n";
print "Sr. No.\tName\tSVM score\tPrediction\n";

system "/usr/bin/perl dipeptide.pl seq.final temp > seq.dipep";
    
@models=('hsp100_dipep_model','hsp20_dipep_model','hsp40_dipep_model','hsp60_dipep_model','hsp70_dipep_model','hsp90_dipep_model');
@model_name=('HSP100','HSP20','HSP40','HSP60','HSP70','HSP90');

open(FH,">svm.out") or die "$!";

open(INPUT,"seq.dipep") or die "$!";
while($line=<INPUT>)
{
    $count++;
    print OUTPUT "$count\t";
    print "$count\t";
    chomp($line);
    @temp_dp=split('#',$line);
    print OUTPUT "$temp_dp[0]\t";
    print "$temp_dp[0]\t";
    open(DIPEP_TEMP,">temp_dipep") or die "$!";
    print DIPEP_TEMP "$temp_dp[1] $temp_dp[2]\n";
    close DIPEP_TEMP;
	
    system "/usr/local/bin/svm_classify temp_dipep hsp_dipep_1st_level_model 1st_level_prediction > /dev/null";
    $first_level_svm_score= `/usr/bin/head -1 1st_level_prediction` ;
    chomp($first_level_svm_score);
    print "$first_level_svm_score";
	

    if($first_level_svm_score < $svm_th)
    {
	print OUTPUT "$svm_th\tNot HSP\n";
	print "$svm_th\tNot HSP\n";
    }
    elsif($first_level_svm_score >= $svm_th)
    {
	#print "==> $svm_th HSP";
	for($a=0;$a<=$#models;$a++)
	{
	    system "/usr/local/bin/svm_classify temp_dipep $models[$a] prediction > /dev/null";
	    $second_level_svm_score= `/usr/bin/head -1 prediction` ;
	    chomp($second_level_svm_score);
	    print FH "$second_level_svm_score:$model_name[$a]\n";
	}
	#system "cat svm.out";
	$max_score=`/usr/bin/sort -nrk 1 -t ':' svm.out|head -1`;
	chomp($max_score);
	#print " Max Score $max_score \n";
	@temp_score=split(':',$max_score);
	print OUTPUT "$temp_score[0]\t$temp_score[1]\n";
	print "$temp_score[0]\t$temp_score[1]\n";
    }
    #print "Press Enter\n";
    #$R=<STDIN>;
}
close INPUT;
close OUTPUT;
close FH;
system "rm 1st_level_prediction svm.out temp temp_dipep prediction seq.dipep seq.final";
